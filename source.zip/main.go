/*
Copyright © 2023 sknoww sknow.codes@gmail.com
*/
package main

import (
	"github.com/sknoww/sknowR/cmd"
)

func main() {
	cmd.Execute()
}
